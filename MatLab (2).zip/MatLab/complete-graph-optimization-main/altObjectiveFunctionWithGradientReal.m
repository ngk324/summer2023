function [value,gradient] =altObjectiveFunctionWithGradientReal(w,params,G)

    %% Collect parameters
    nVertices = params.nVertices;
    h = params.h;
    gamma = params.gamma;

    %% Collect Matrices and Eigendecompose
    newGraph = graph();
    for i=1:G.numedges
        edge = G.Edges(i,1).EndNodes;
        % weight = G.Edges(i,2);
        weight = w(i);
        newGraph = addedge(newGraph,edge(1),edge(2),weight);
    end
    [~,~,L] = ADL_from_G(newGraph);
    [U,diag_lambda] = eig(L + params.eps*eye(length(L)));
    lambda = diag(diag_lambda);

    
    %% Compute objective value
    value = 0;
    for i=1:length(lambda)
        lambda_i = lambda(i);
        for j=1:length(lambda)
            lambda_j = lambda(j);
            value = value + ((h*(h^2+lambda_j)+h*lambda_i)...
                /(gamma*nVertices*lambda_j*(lambda_i^2+2*lambda_i*(h^2-lambda_j)+(h^2+lambda_j)^2)));
        end
    end
    value = value/nVertices;
    %% Compute the gradient
    if nargout > 1
        sumOverL = zeros(length(lambda),1);
        for i=1:length(lambda)
            lambda_i = lambda(i);
            for l=1:length(lambda)
                lambda_l = lambda(l);
                sumOverL(i) = sumOverL(i) + (-(h*(h^6*lambda_l+h^4*(lambda_i+lambda_l)*(lambda_i+3*lambda_l)+...
                              (lambda_i-lambda_l)*(lambda_i+lambda_l)*(lambda_i^2+4*lambda_i*lambda_l-lambda_l^2)+...
                              h^2*(2*lambda_i^3+3*lambda_i^2*lambda_l+3*lambda_l^3)))/(lambda_i^2*lambda_l*(h^4+(lambda_i-lambda_l)^2+2*h^2*(lambda_i+lambda_l))^2));
            end
        end
        idx = 1;
        gradient = zeros(length(w),1);
        for i=1:nVertices
            for j=i+1:nVertices
                for k=1:length(lambda)
                    gradient(idx) = gradient(idx) + sumOverL(k)*(U(i,k)-U(j,k))^2;
                end
                idx = idx+1;
            end
        end
    end
end