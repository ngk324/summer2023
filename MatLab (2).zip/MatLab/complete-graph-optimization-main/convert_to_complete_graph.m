function G_complete = convert_to_complete_graph(G,w)
    G_complete = G;
    A = adjacency(G);
    for i=1:length(A)
        for j=i+1:length(A)
            if(A(i,j)==0)
                G_complete = addedge(G_complete,i,j,w);
            end
        end
    end
end

