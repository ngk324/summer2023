function [A,D,L] = generateMatricesFromWeights(weightVector,nVertices)
    if(length(weightVector) ~= (nVertices*(nVertices-1)/2))
        error("Weight vector and nVertices mismatch at generateMatricesFromWeights");
    end

    %% Generate the adjacency matrix assuming a uniform grid
    A = zeros(nVertices);
    idx = 1;
    for i=1:nVertices
        for j=i+1:nVertices
            A(i,j) = weightVector(idx);
            % Symmetric elements
            A(j,i) = A(i,j);
            idx = idx+1;
        end
    end

    D = zeros(nVertices);
    L = zeros(nVertices);


    %% Generate Degree and Laplacian Matrices
    D = zeros(size(A));
    for i=1:length(D(:,1))
        D(i,i) = sum(A(i,:));
    end
    L = D - A;

end

