clc; clear all;

%% Some parameters
params.nVertices = 103; % changed
params.h = 0.1;             % Coefficient a of the objective function
params.eps = 0.1;           % Small dampening added to the laplacian before
                            % computing the eigenvalues
params.gamma = 0.001;
params.minWeight = 0.1;     % Constraint for weights
params.randEps = 0.3;

%% Initialization

fid = fopen('data/as1.txt', 'r' ); % changed 
formatSpec = '%d %f';
sizeA = [2 Inf];
A = fscanf(fid,formatSpec,sizeA);
fclose(fid);
x=A(1,:)';
y=A(2,:)';

G_init = graph(x,y,ones(length(x),1));

G_init = simplify(G_init);

% G_init = convert_to_complete_graph(G_init,params.minWeight); % changed

[A_init,D_init,L_init] = ADL_from_G(G_init);
[~,diag_lambda_init] = eig(L_init + params.eps*eye(length(L_init)));
lambda_init = diag(diag_lambda_init);



w0 = G_init.Edges(:,2).Variables;

% with perturbation
%perturbation = -params.randEps + 2*params.randEps*rand(length(w0),1);
%w0 = w0 + perturbation;

objFuncHandle = @altObjectiveFunctionWithGradientReal;

disp(['Initial Objective Value: ' ...
    num2str(objFuncHandle(w0,params,G_init))])

fid = fopen('dataResults\EVresultsInit.txt', 'wt' );
for i = 1:length(lambda_init)
    if(i ~= length(lambda_init))
        fprintf( fid, '%f\n', lambda_init(i) );
    else
        fprintf( fid, '%f', lambda_init(i) );
    end
end
fclose(fid);


fid = fopen('dataResults\LapResultsInit.txt', 'wt' );

for i = 1:length(L_init)
    for j = 1:length(L_init)
        if(i * j ~= length(L_init)*length(L_init))
            fprintf( fid, '%f\n', L_init(i,j) );
        else
            fprintf( fid, '%f', L_init(i,j) );
        end
    end
end
fclose(fid);

% No linear inequality constraints
A = [];
b = [];

% Weight sum constraint implemented as a linear constraint
Aeq = ones(1,G_init.numedges);
beq = sum(w0);

% It is possible to provide lower and upper bounds for the weights
lb = params.minWeight*ones(G_init.numedges,1);
ub = inf*ones(G_init.numedges,1);

% No nonlinear constraints
nonlcon = [];

% Use options for utilizing the known gradient
%options = optimoptions('fmincon','SpecifyObjectiveGradient',false,'MaxFunctionEvaluations',1e+5);
options = optimoptions('fmincon','SpecifyObjectiveGradient',true);

w = fmincon(@(w)objFuncHandle(w,params,G_init),w0,A,b,Aeq,beq,...
    lb,ub,nonlcon,options);

disp(['Final Objective Value: ' ...
    num2str(objFuncHandle(w,params,G_init))])

%% Post Processing for Generating Histograms
G_final = graph();
for i=1:G_init.numedges
    edge = G_init.Edges(i,1).EndNodes;
    weight = w(i);
    G_final = addedge(G_final,edge(1),edge(2),weight);
end
[A_final,D_final,L_final] = ADL_from_G(G_final);
[~,diag_lambda_final] = eig(L_final + params.eps*eye(length(L_final)));
lambda_final = diag(diag_lambda_final);


fid = fopen('dataResults\EVresults.txt', 'wt' );
for i = 1:length(lambda_final)
    if(i ~= length(lambda_final))
        fprintf( fid, '%f\n', lambda_final(i) );
    else
        fprintf( fid, '%f', lambda_final(i) );
    end
end
fclose(fid);


fid = fopen('dataResults\LapResults.txt', 'wt' );

for i = 1:length(L_final)
    for j = 1:length(L_final)
        if(i * j ~= length(L_final)*length(L_final))
            fprintf( fid, '%f\n', L_final(i,j) );
        else
            fprintf( fid, '%f', L_final(i,j) );
        end
    end
end
fclose(fid);


figure()
subplot(1,2,1)
hist_init = histogram(lambda_init,10);
maxFreq = max(hist_init.BinCounts);
ylim([0,maxFreq])
title("Initial spectrum")
xlabel("Eigenvalue")
ylabel("Frequency")
subplot(1,2,2)
hist_final = histogram(lambda_final,10);
ylim([0,maxFreq])
title("Final spectrum")
xlabel("Eigenvalue")
ylabel("Frequency")



