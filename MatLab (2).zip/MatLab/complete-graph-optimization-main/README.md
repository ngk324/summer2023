# complete-graph-optimization
Eigenspectrum optimization for reducing resonance in a complete graph network
