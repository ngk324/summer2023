clc; clear all;

%fid = fopen('social-complete-graph-lap-ev-data\LapResultsInit.txt', 'r' );
%fid = fopen('uniform-complete-graph-lap-ev-data\LapResultsInitC.txt', 'r' );
fid = fopen('newMethodData\LapResultsInit.txt', 'r' );
formatSpec = '%f';
A1 = fscanf(fid,formatSpec);
fclose(fid);

%fid = fopen('uniform-complete-graph-lap-ev-data\LapResultsC.txt', 'r' );
%fid = fopen('social-complete-graph-lap-ev-data\LapResults.txt', 'r' );
fid = fopen('newMethodData\LapResults.txt', 'r' );
formatSpec = '%f';
A2 = fscanf(fid,formatSpec);
fclose(fid);

fid = fopen('frequencies.txt', 'r' );
formatSpec = '%f';
A3 = fscanf(fid,formatSpec);
fclose(fid);

numNodes = 96;
%numNodes = 100;
D = 0.001;
L_init = zeros(numNodes,numNodes);
counter = 1;
for i=1:numNodes
    for j=1:numNodes
        L_init(i,j) = A1(counter);
        counter  = counter + 1;
    end
end

L = zeros(numNodes,numNodes);
counter = 1;
for i=1:numNodes
    for j=1:numNodes
        L(i,j) = A2(counter);
        counter  = counter + 1;
    end
end

counter = 1;

fileID1 = fopen('twoNormBeforeNewNonRandAvg.txt','w');
fileID2 = fopen('twoNormAfterNewNonRandAvg.txt','w');

finalSum1 = 0;
finalSum2 = 0;

for i=1:length(A3)
    disp(i);
    final1=0;
    final2=0;
    if(mod(i,2) == 1)
        freq1 = A3(counter);
        temp = 0;
        for j=1:numNodes
            temp = temp + abs(calc_steady_state(freq1,numNodes,D,L_init,j));
        end
        final1 = sqrt(temp / numNodes);
        fprintf(fileID1,'%6.8f\n',final1);
        finalSum1 = finalSum1 + final1;
        counter = counter + 1;
    end

    if(mod(i,2) == 0)
        freq2 = A3(counter);
        temp = 0;
        for j=1:numNodes
            temp = temp + abs(calc_steady_state(freq2,numNodes,D,L_init,j));
        end
        final2 = sqrt(temp / numNodes);
        fprintf(fileID2,'%6.8f\n',final2);
        finalSum2 = finalSum2 + final2;
        counter = counter + 1;
    end

      
end

finalSum1 = finalSum1 / 9600;
finalSum2 = finalSum2 / 9600;


fprintf(fileID1,'%6.8f\n',finalSum1);
fprintf(fileID2,'%6.8f\n',finalSum2);


fclose(fileID1);
fclose(fileID2);

disp('Initial Steady State');
disp(finalSum1);

disp('Steady State after Gradient Descent');
disp(finalSum2);


   %{ 
final1 = calc_steady_state2(freq1,numNodes,D,L_init,89);
disp('Initial Steady State');
disp(final1);

final2 = calc_steady_state2(freq2,numNodes,D,L,89);
disp('Steady State after Gradient Descent');
disp(final2);
   %}