
function[final] = calc_steady_state2(freq,numNodes,D,L,forceVec)
        
        x_bar = inv(-freq*freq*eye(numNodes)+freq*D*eye(numNodes)*sqrt(-1)+(L+eye(numNodes)*0.1))*forceVec;
        
        final = norm(x_bar)^2;
        
end