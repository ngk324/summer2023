
function[final] = calc_steady_state(freq,numNodes,D,L,forceNode)
        
        u = zeros(numNodes,1);
        u(forceNode) = 1;
        
        x_bar = inv(-freq*freq*eye(numNodes)+freq*D*eye(numNodes)*sqrt(-1)+(L+eye(numNodes)*0.1))*u;
        
        final = norm(x_bar)^2;
        
end