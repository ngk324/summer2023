function[final_freq] = sample_freq(freq, rand_prob, h)
        
        final_freq = sqrt(freq) + h*tan(pi*(rand_prob-0.5));
        
end